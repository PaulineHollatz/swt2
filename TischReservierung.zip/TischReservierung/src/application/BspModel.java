package application;

import java.io.IOException;

public class BspModel extends Reservierungsfenster {
 

	    public BspModel() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

		private String hello = "Hello World!"; 
	     
	    public String getHello() { 
	        return hello; 
	    } 
	
}
