package application;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;

 

public class FXMLController implements Initializable {

	Reservierungsfenster model;
	@FXML
	private void handleButtonAction(ActionEvent event) throws IOException{
		System.out.println("Hallo");
		new Reservierungsfenster();
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			model = new BspModel();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
